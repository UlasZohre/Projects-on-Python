print(
    "1 = Brush down\n"
    "2 = Brush up\n"
    "3 = Turn right\n"
    "4 = Turn left\n"
    "5 = move up to x\n"
    "6 = Jump (Jump as 3 square except the square where it is located. After jumping, the brush comes up\n"
    "7 = Reverse direction\n"
    "8 = View the matrix\n"
    "0 = End program."
)
def brushmv(brush, i):
    if i == "1":
        brush += 1
    elif i == "2":
        brush -= 1
    if int(brush) > 2:
        brush -= 1
    if int(brush) < 0:
        brush += 1
    return brush


def mvdirection(i, direction):
    if i == "3":
        direction += 1
    elif i == "4":
        direction -= 1
    elif i == "7":
        direction += 2
    if direction > 2:
        direction -= 4
    if direction < -1:
        direction += 4
    return direction


def movement(direction, i, array, positionx, positiony, brush, row):
    if i.split('_')[0] == "5":
        tilenumber = int(i.split("_")[1])
        turn = 0
        if direction == 0:
            while turn < tilenumber:
                if brush == 1:
                    array[positionx][positiony] = "*"
                if positiony == len(array) - 2:
                    positiony = 0
                positiony += 1
                turn += 1

        elif direction == 1:
            while turn < tilenumber:
                if brush == 1:
                    array[positionx][positiony] = "*"
                if positionx == len(array) - 2:
                    positionx = 0
                positionx += 1
                turn += 1

        elif direction == 2:
            while turn < tilenumber:
                if brush == 1:
                    array[positionx][positiony] = "*"
                if positiony == 1:
                    positiony = len(array) - 1
                positiony -= 1
                turn += 1

        elif direction == -1:
            while turn < tilenumber:
                if brush == 1:
                    array[positionx][positiony] = "*"
                if positionx == 1:
                    positionx = len(array) - 1
                positionx -= 1
                turn += 1
        if brush == 1:
            array[positionx][positiony] = "*"
        return positionx, positiony, array

    elif i == "6":
        if direction == 0:
            if brush == 1:
                array[positionx][positiony] = "*"
            positiony += 3
            if positiony >= len(array) - 2:
                positiony -= row

        elif direction == 1:
            if brush == 1:
                array[positionx][positiony] = "*"
            positionx += 3
            if positionx >= len(array) - 2:
                positionx -= row

        elif direction == 2:
            if brush == 1:
                array[positionx][positiony] = "*"
            positiony -= 3
            if positiony <= 0:
                positiony += row

        elif direction == -1:
            if brush == 1:
                array[positionx][positiony] = "*"
            positionx -= 3
            if positionx <= 0:
                positionx += row

        return positionx, positiony, array


def printarray(array):
    for a in range(0, row + 2):
        if a == 0 or a == row + 1:
            print("+" * (row + 2))
            continue
        for b in range(0, row + 2):
            if b == 0 or b == row + 1:
                print("+", end="")
            else:
                if array[a][b] == " ":
                    print(" ", end="")
                else:
                    print("*", end="")
        print()

while True:
    commands = input("Enter your commands while sperating them with '+': ").split("+")
    commands = list(commands)
    row = int(commands[0])
    array = [[" "] * (row + 2) for i in range(row + 2)]

    positionx = 1
    positiony = 1

    direction = 0
    brush = 0
    error_detect = False

    for i in commands[1::]:
        if i != "0" and i != "1" and i != "2" and i != "3" and i != "4" and i.split('_')[0] != "5" and i != "6" and i != "7" and i != "8":
            print("Invalid command detected. Please try again.")
            error_detect = True
            break

    if error_detect:
        continue

    for i in commands[1:]:
        if i == "1" or i == "2":
            brush = brushmv(brush, i)
        elif i == "3" or i == "4" or i == "7":
            direction = mvdirection(i, direction)
        elif i.split('_')[0] == "5" or i == "6":
            positionx, positiony, array = movement(direction, i, array, positionx, positiony, brush, row)
            if i == "6":
                brush = 0
        elif i == "8":
            printarray(array)
        elif i == "0":
            break
    break
