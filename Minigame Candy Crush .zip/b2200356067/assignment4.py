import sys

with open(sys.argv[1], "r") as file:
    map2 = file.read().splitlines()
    map1 = list()
    for i in range(len(map2)):
        map1.append(list(map2[i]))

for i in range(len(map1)):
    for j in map1[i]:
        if j == ' ':
            map1[i].remove(j)

def delright(map1, x, y, dellist):
    row = x
    column = y
    if [row, column + 1] in dellist:
        return
    while column <= len(map1[row]):
        if column + 1 > len(map1[row]) - 1:
            return
        if map1[row][column] == map1[row][column + 1]:

            dellist.append([row, column + 1])
            column += 1
            delup(map1, row, column, dellist)
            deldown(map1, row, column, dellist)
        else:
            return
    return

def delleft(map1, x, y, dellist):
    row = x
    column = y
    if [row, column - 1] in dellist:
        return
    while column >= 0:
        if column - 1 < 0:
            return
        elif map1[row][column] == map1[row][column - 1]:

            dellist.append([row, column - 1])
            column -= 1
            delup(map1, row, column, dellist)
            deldown(map1, row, column, dellist)

        else:
            return
    return

def delup(map1, x, y, dellist):
    row = x
    column = y
    if [row - 1, column] in dellist:
        return
    while row >= 0:
        if row - 1 < 0:
            return
        elif map1[row][column] == map1[row - 1][column]:

            dellist.append([row - 1, column])
            row -= 1
            delright(map1, row, column, dellist)
            delleft(map1, row, column, dellist)
        else:
            return
    return

def deldown(map1, x, y, dellist):
    row = x
    column = y
    if [row + 1, column] in dellist:
        return
    while row <= len(map1):
        if row + 1 > len(map1) - 1:
            return
        elif map1[row][column] == map1[row + 1][column]:
            dellist.append([row + 1, column])
            row += 1
            delright(map1, row, column, dellist)
            delleft(map1, row, column, dellist)
        else:
            return
    return

def bomb(map1, x, y):
    dellist = list()
    chain = list()
    row = x
    column = y
    global points
    for i in range(len(map1[row])):
        dellist.append([row, i])
    for i in range(len(map1)):
        dellist.append([i, column])

    for i in range(len(dellist)):
        if map1[dellist[i][0]][dellist[i][1]] == "X":
            chain.append(dellist[i])

    points = bombpoints(map1, dellist)

    for i in range(len(dellist)):
        map1[dellist[i][0]][dellist[i][1]] = ""
    map1[x][y] = ""

    if len(chain) > 0:
        for i in range(len(chain)):
            bomb(map1, chain[i][0], chain[i][1])
    return

def bombpoints(map1, dellist):
    global points
    for i in range(len(dellist)):
        if map1[dellist[i][0]][dellist[i][1]] == "B":
            points += 9
        elif map1[dellist[i][0]][dellist[i][1]] == "G":
            points += 8
        elif map1[dellist[i][0]][dellist[i][1]] == "W":
            points += 7
        elif map1[dellist[i][0]][dellist[i][1]] == "Y":
            points += 6
        elif map1[dellist[i][0]][dellist[i][1]] == "R":
            points += 5
        elif map1[dellist[i][0]][dellist[i][1]] == "P":
            points += 4
        elif map1[dellist[i][0]][dellist[i][1]] == "O":
            points += 3
        elif map1[dellist[i][0]][dellist[i][1]] == "D":
            points += 2
        elif map1[dellist[i][0]][dellist[i][1]] == "F":
            points += 1
        elif map1[dellist[i][0]][dellist[i][1]] == "X":
            points += 0
        elif map1[dellist[i][0]][dellist[i][1]] == "":
            points += 0
    return points

def pointsystem(map1, x, y, dellist):
    global points
    if map1[x][y] == "B":  # Black
        points += 9 * (len(dellist))
    elif map1[x][y] == "G":  # Gray
        points += 8 * (len(dellist))
    elif map1[x][y] == "W":  # White
        points += 7 * (len(dellist))
    elif map1[x][y] == "Y":  # Yellow
        points += 6 * (len(dellist))
    elif map1[x][y] == "R":  # Red
        points += 5 * (len(dellist))
    elif map1[x][y] == "P":  # Pink
        points += 4 * (len(dellist))
    elif map1[x][y] == "O":  # Orange
        points += 3 * (len(dellist))
    elif map1[x][y] == "D":  # Dark Blue
        points += 2 * (len(dellist))
    elif map1[x][y] == "F":  # Fuschia
        points += 1 * (len(dellist))
    return points

points = 0

def delfunc(map1, x, y):
    global points
    dellist = list()

    delright(map1, x, y, dellist)
    delleft(map1, x, y, dellist)
    delup(map1, x, y, dellist)
    deldown(map1, x, y, dellist)
    dellist.append([x,y])
    dellist = list(list(t) for t in set(tuple(element) for element in dellist))
    if len(dellist) <= 1:
        return
    else:
        points = pointsystem(map1, x, y, dellist)
        for i in range(len(dellist)):
            map1[dellist[i][0]][dellist[i][1]] = ""
    return

def falldown(map1):
    for j in range(len(map1[0])):
        end = False
        for i in range(len(map1) - 1, -1, -1):
            counter = 0
            while map1[i][j] == "":
                for x in range(i, 0, -1):
                    map1[x][j] = map1[x - 1][j]
                    map1[x-1][j] = ""
                counter += 1
                if counter > i:
                    end = True
                    break
            if end:
                break
    i = 0
    while i < len(map1):
        allempty = True
        row = list()
        for j in range(len(map1[i])):
            row.append(map1[i][j])
        for j in row:
            if j != "":
                allempty = False
                break
        if allempty:
            map1.pop(i)
        else:
            i += 1

def delemptycolumn(map1):
    j = 0
    while j < len(map1[0]):
        allempty = True
        sutun = list()
        for i in range(len(map1)):
            sutun.append(map1[i][j])
        for i in sutun:
            if i != "":
                allempty = False
                break

        if allempty:
            for i in range(len(map1)):
                map1[i].pop(j)
        else:
            j += 1

def check(map1):
    if len(map1) == 1:
        for j in range(len(map1[0])):
            if j == 0:
                if map1[0][j] == map1[0][j+1]:
                    return True
            elif j == len(map1[0]) - 1:
                if map1[0][j] == map1[0][j-1]:
                    return True
            else:
                if map1[0][j] == map1[0][j+1] or map1[0][j] == map1[0][j-1]:
                    return True
    else:
        for i in range(len(map1)):
            for j in range(len(map1[i])):
                if map1[i][j] == "":
                    continue
                if i == 0 and j == 0:
                    if map1[i][j] == map1[i+1][j] or map1[i][j] == map1[i][j+1]:
                        return True
                elif i == 0 and j == len(map1[i]) - 1:
                    if map1[i][j] == map1[i+1][j] or map1[i][j] == map1[i][j-1]:
                        return True
                elif j == 0 and i == len(map1) - 1:
                    if map1[i][j] == map1[i-1][j] or map1[i][j] == map1[i][j-1]:
                        return True
                elif i == len(map1) - 1 and j == len(map1[i]) - 1:
                    if map1[i][j] == map1[i-1][j] or map1[i][j] == map1[i][j-1]:
                        return True
                elif i == 0:
                    if map1[i][j] == map1[i+1][j] or map1[i][j] == map1[i][j+1] or map1[i][j] == map1[i][j-1]:
                        return True
                elif j == 0:
                    if map1[i][j] == map1[i-1][j] or map1[i][j] == map1[i][j+1] or map1[i][j] == map1[i+1][j]:
                        return True
                elif i == len(map1) - 1:
                    if map1[i][j] == map1[i-1][j] or map1[i][j] == map1[i][j-1] or map1[i][j] == map1[i][j+1]:
                        return True
                elif j == len(map1[i]) - 1:
                    if map1[i][j] == map1[i+1][j] or map1[i][j] == map1[i-1][j] or map1[i][j] == map1[i][j-1]:
                        return True
                else:
                    if map1[i][j] == map1[i+1][j] or map1[i][j] == map1[i-1][j] or map1[i][j] == map1[i][j+1] or \
                        map1[i][j] == map1[i][j-1]:
                        return True
    return False

while True:
    check(map1)
    print('\n'.join(['\t'.join(str(cell) for cell in row) for row in map1]))
    print("")
    print("You have {} points".format(points))
    print("")
    if check(map1):
        x, y = input("Please enter a row and column number: ").split()
        print("")
        x = int(x)
        y = int(y)
        try:
            if x > len(map1) or y > len(map1[0]):
                raise IndexError
            if map1[x][y] == "" or x not in range(len(map1)):
                raise IndexError
            if y not in range(len(map1[x])):
                raise IndexError
        except IndexError:
            print("Please enter a valid size.")
            continue
        if map1[x][y] == "X":
            bomb(map1, x, y)
        else:
            delfunc(map1, x, y)
        falldown(map1)
        delemptycolumn(map1)
    else:
        print("Game over.")
        break
