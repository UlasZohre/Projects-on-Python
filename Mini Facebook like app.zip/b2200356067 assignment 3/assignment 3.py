import sys
with open(sys.argv[1], "r") as persons:
    paf = dict()  # persons and friends
    person_list = persons.read().splitlines()
    pl = list()  # person list


    for i in range(len(person_list)):
        ind = 0
        for j in person_list[i]:
            if j == "'":
                person_list.remove(j)
            if j != ":":
                ind += 1
            else:
                pl.append(person_list[i][0:ind])
                paf[person_list[i][0:ind]] = person_list[i][ind + 1:len(person_list[i]) ]

u = 0
for i in paf.values():
    i = list(i.split(" "))
    while '' in i:
        i.remove('')
    paf[pl[u]] = i
    u += 1

def ANU(user_name):  # Add new user

    if user_name in pl:
        output.write("ERROR: Wrong input type! for 'ANU'! -- This user already exists!!\n")
        return
    else:
        pl.append(user_name)
        paf[user_name] = []
        output.write("User '{}' has been added to the social network successfully.\n".format(user_name))
        return pl and paf

def DEU(username):  # Delete existing user #relations doesn't deleted rn
    if username not in pl:
        output.write("ERROR: Wrong input type! for 'DEU'!--There is no user named '{}'!!\n".format(username))
        return
    u = pl.index(username)
    
    del (paf[pl[u]])
    del (pl[u])
    
    for a in range(len(pl)):
        if username not in paf[pl[a]]:
            continue
        b = paf[pl[a]].index(username)
        paf[pl[a]].pop(b)

    output.write("User '{}' and his/her all relations have been deleted successfully\n".format(username))
    return paf and pl

def ANF(user, friend):  # Add new friend

    if user not in pl and friend in pl:
        output.write("ERROR: Wrong input type! for 'ANF'! -- No user named '{}' found!!\n".format(user))
        return
    if user in pl and friend not in pl:
        output.write("ERROR: Wrong input type! for 'ANF'! -- No user named '{}' found!!\n".format(friend))
        return
    if user and friend not in pl:
        output.write("ERROR: Wrong input type! for 'ANF'! -- No user named '{}' and '{}' found!\n".format(user, friend))
        return
    if friend in paf[user]:
        output.write("ERROR: A relation between '{}' and '{}' already exists!!\n".format(user, friend))
        return
    paf[user].append(friend)
    paf[friend].append(user)

    output.write("Relation between '{}' and '{}' has been added successfully\n".format(user, friend))
    return paf

def DEF(user, friend):  # Delete existing friend #d
    if user not in pl and friend in pl:
        output.write("ERROR: Wrong input type! for 'DEF'! -- No user named '{}' found!\n".format(user))
        return
    elif user in pl and friend not in pl:
        output.write("ERROR: Wrong input type! for 'DEF'! -- No user named '{}' found!\n".format(friend))
        return
    elif user and friend not in pl:
        output.write("ERROR: Wrong input type! for 'DEF'! -- No user named '{}' and '{}' found!\n".format(user, friend))
        return
    if friend not in paf[user]:
        output.write("ERROR: No relation between '{}' and '{}' found!!\n".format(user, friend))
        return

    elif friend not in paf[user]:
        output.write("ERROR: No relation between '{}' and {} found!!\n".format(user, friend))
        return
    else:
        u = paf[user].index(friend)
        paf[user].pop(u)
    a = paf[friend].index(user)
    paf[friend].pop(a)
    output.write("Relation between '{}' and '{}' has been deleted successfully.\n".format(user, friend))
    return paf

def CF(user):  # Give the number of existing users friends
    i = 0
    if user not in pl:
        output.write("ERROR: Wrong input type! for 'CF'! -- No user named '{}' found!\n".format(user))
        return
    elif pl[i] != user:
        i += 1

    output.write("User '{}' has {} friends.\n".format(user, len(paf[user])))

def FPF(user, maxdis):  # Find possible friends
    dis = 1
    i = 0
    midlist = list()
    if int(maxdis) < 1 or int(maxdis) > 3:
        output.write("Error. Max disant can t be larger than 3 or lesser than 1.\n")
        return
    if user not in pl:
        output.write("ERROR: Wrong input type! for 'FPF'! -- No user named '{}' found!\n".format(user))
        return

    for a in paf[user]:
        midlist.append(a)
    if dis < int(maxdis):
        while dis < int(maxdis):
            for b in range(len(midlist)):
                midlist += paf[midlist[b]]
            dis += 1

    while user in midlist:
        midlist.remove(user)
    final = set(midlist)


    final = sorted(final)
    
    output.write("User '{}' has {} possible friends when maximum distance is {}\n".format(user, len(final), maxdis))
    final = str(final)
    output.write("These possible friends are: {}\n".format(final[1:-1]))

def SF(user, MD):  # Suggest friend to existing user

    ptc = list()

    sgf = list()
    if int(MD) < 1 or int(MD) > 4:
        output.write("Error: Mutually Degree cannot be less than 1 or greater than 4.\n")
        return
    if user not in pl:
        output.write("Error: Wrong input type! for 'SF'! -- No user named '{}' found!!\n".format(user))
        return
    for b in range(len(pl)):
        md = 0
        for j in pl:

            if j in paf[pl[b]] and j in paf[user]:
                md += 1

        if md >= int(MD):
            if pl[b] == user or pl[b] in sgf:
                continue
            sgf.append(pl[b])

    output.write("Suggestion List for '{}' (when MD is {}):\n".format(user, len(sgf), MD))
    sgf = list()
    for a in range(len(pl)):
        if pl[a] not in paf[user]:
            if pl[a] == user:
                continue
            ptc.append(pl[a])
    for b in range(len(pl)):
        md = 0
        for j in pl:

            if j in paf[pl[b]] and j in paf[user]:
                md += 1

        if md >= int(MD):
            if pl[b] == user or pl[b] in sgf:
                continue
            sgf.append(pl[b])
            output.write("'{}' has {} mutual friends with '{}'.\n".format(user, md,pl[b] ))
    sgf = str(sgf)
    output.write("The suggested friends for '{}': {}.\n".format(user, sgf[1:-1]))

with open(sys.argv[2], "r") as commands:
    cmnds = commands.read().splitlines()
    cmndsf = list()
    for a in range(len(cmnds)):
        cmndsf.append(list(cmnds[a].split(" ")))

with open("myoutput.txt","w") as output:
    for a in range(len(cmndsf)):
        if cmndsf[a][0] == "ANU":
            ANU(cmndsf[a][1])
        elif cmndsf[a][0] == "DEU":
            DEU(cmndsf[a][1])
        elif cmndsf[a][0] == "ANF":
            ANF(cmndsf[a][1], cmndsf[a][2])
        elif cmndsf[a][0] == "DEF":
            DEF(cmndsf[a][1], cmndsf[a][2])
        elif cmndsf[a][0] == "CF":
            CF(cmndsf[a][1])
        elif cmndsf[a][0] == "FPF":
            FPF(cmndsf[a][1], cmndsf[a][2])
        elif cmndsf[a][0] == "SF":
            SF(cmndsf[a][1],cmndsf[a][2])
